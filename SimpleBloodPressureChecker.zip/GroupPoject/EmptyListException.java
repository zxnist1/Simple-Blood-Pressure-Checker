

public class EmptyListException extends RuntimeException 
{
    public EmptyListException()
    {
        super("This List Is Empty");
    }
}
